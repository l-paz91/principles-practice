// -----------------------------------------------------------------------------
#ifndef _COLOURGRADIENT_H_
#define _COLOURGRADIENT_H_
// -----------------------------------------------------------------------------

//--INCLUDES--//
#include "std_lib_facilities.h"

// -----------------------------------------------------------------------------

struct ColourPoint
{
	ColourPoint(float red, float green, float blue, float value)
		: r(red)
		, g(green)
		, b(blue)
		, val(value)
	{}

	float r, g, b;
	float val;
};

// -----------------------------------------------------------------------------

class ColourGradient
{
public:
	enum BPP {
		BIT15, BIT24
	};

	//default constructor
	ColourGradient() { createDefaultHeatMapGradient(); }

	//inserts a new colour point into its correct position
	void addColourPoint(double red, double green, double blue, double value);

	//clears the gradient stored in v_colour
	void clearGradient() { v_colour.clear(); }

	//places a 5 colour heatmap gradient into v_colour
	void createDefaultHeatMapGradient();

	//6 colour heatmap red-yellow-green-cyan-blue-magenta-red
	void createSixColourHeatMap();

	//6 colour heatmap from red-yellow-green-cyan-blue-magenta-red (15-BIT)
	void createSixColourHeatMap15BIT();

	//inputs a (value) between 0 and 1 and outputs the (red), (green) and (blue)
	//values representing that position in the gradient
	void getColourAtValue(const double value, double& red, double& green, double& blue, BPP bitNumber);

private:
	vector<ColourPoint> v_colour;

};

#endif // !_COLOURGRADIENT_H_

