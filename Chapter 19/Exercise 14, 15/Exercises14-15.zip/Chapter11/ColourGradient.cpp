// -----------------------------------------------------------------------------

//--INCLUDES--//
#include "ColourGradient.h"

// -----------------------------------------------------------------------------

void ColourGradient::addColourPoint(double red, double green, double blue, double value)
{
	for (int i = 0; i < v_colour.size(); ++i)
	{
		if (value < v_colour[i].val)
		{
			v_colour.insert(v_colour.begin() + i, ColourPoint(red, green, blue, value));
			return;
		}
	}
	v_colour.push_back(ColourPoint(red, green, blue, value));
}

// -----------------------------------------------------------------------------

//5 colour heatmap from blue-cyan-green-yellow-red
void ColourGradient::createDefaultHeatMapGradient()
{
	v_colour.clear();
	v_colour.push_back(ColourPoint(0, 0, 255, 0.0f));		//blue
	v_colour.push_back(ColourPoint(0, 255, 255, 0.25f));	//cyan
	v_colour.push_back(ColourPoint(0, 255, 0, 0.5f));		//green
	v_colour.push_back(ColourPoint(255, 255, 0, 0.75f));	//yellow
	v_colour.push_back(ColourPoint(255, 0, 0, 1.0f));		//red
}

//6 colour heatmap from red-yellow-green-cyan-blue-magenta-red
void ColourGradient::createSixColourHeatMap()
{
	v_colour.clear();
	v_colour.push_back(ColourPoint(255, 0, 0, 0.0f));		//red
	v_colour.push_back(ColourPoint(255, 255, 0, 0.125f));	//yellow
	v_colour.push_back(ColourPoint(0, 255, 0, 0.25f));		//green
	v_colour.push_back(ColourPoint(0, 255, 255, 0.5f));		//cyan
	v_colour.push_back(ColourPoint(0, 0, 255, 0.625f));		//blue
	v_colour.push_back(ColourPoint(255, 0, 255, 0.75f));	//magenta
	v_colour.push_back(ColourPoint(255, 0, 0, 1.0f));		//red
}

//6 colour heatmap from red-yellow-green-cyan-blue-magenta-red (15-BIT)
void ColourGradient::createSixColourHeatMap15BIT()
{
	v_colour.clear();
	v_colour.push_back(ColourPoint(31, 0, 0, 0.0f));		//red
	v_colour.push_back(ColourPoint(31, 31, 0, 0.125f));		//yellow
	v_colour.push_back(ColourPoint(0, 31, 0, 0.25f));		//green
	v_colour.push_back(ColourPoint(0, 31, 31, 0.5f));		//cyan
	v_colour.push_back(ColourPoint(0, 0, 31, 0.625f));		//blue
	v_colour.push_back(ColourPoint(31, 0, 31, 0.75f));		//magenta
	v_colour.push_back(ColourPoint(31, 0, 0, 1.0f));		//red
}

// -----------------------------------------------------------------------------

void ColourGradient::getColourAtValue(const double value, double& red, double& green, double& blue, BPP bitNumber)
{
	if (v_colour.size() == 0)
		return;

	float valueDiff, fractBetween;

	for (int i = 0; i < v_colour.size(); ++i)
	{
		ColourPoint& currC = v_colour[i];
		if (value < currC.val)
		{
			ColourPoint& prevC = v_colour[max(0, i - 1)];
			valueDiff = prevC.val - currC.val;
			fractBetween = (valueDiff == 0) ? 0 : (value - currC.val) / valueDiff;
			red   = (prevC.r - currC.r)*fractBetween + currC.r;
			green = (prevC.g - currC.g)*fractBetween + currC.g;
			blue  = (prevC.b - currC.b)*fractBetween + currC.b;

			if (bitNumber == BIT15)
			{
				//convert 15bit to 24bit for display (this rounds and will skip some colours)
				red = round((red / 31.0f)*255.0f);
				blue = round((blue / 31.0f)*255.f);
				green = round((green / 31.0f)*255.0f);
				return;
			}
			return;		
		}
	}

	red   = v_colour.back().r;
	green = v_colour.back().g;
	blue  = v_colour.back().b;
	return;
}

// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------




