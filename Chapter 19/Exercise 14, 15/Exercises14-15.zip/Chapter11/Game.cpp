﻿// -----------------------------------------------------------------------------

//----INCLUDES----//
#include "Game.h"
#include "ConsoleHelpers.h"

#include <conio.h>
#include <fcntl.h>
#include <io.h>
#include <iostream>

// -----------------------------------------------------------------------------
using namespace std;

void Game::titlescreen()
{
	// display the titlescreen & instructions
}

// -----------------------------------------------------------------------------

void Game::instructions()
{
	cout << "- A rather smelly monster lives deep in the dark cave. It is threatening life as we know it." << endl;
	cout << "- The princess wants you to go and slay the Wumpus. You are the only one that can do it..." << endl;
	cout << "- The cave has two hazards; bottomless pits and giant bats." << endl;
	cout << "- If you enter a room with a pit and you have no planks, it's the end of the game." << endl;
	cout << "- If you enter a room with a bat, it will pick you up and drop you in another room." << endl;
	cout << "- If you enter a room with the wumpus, or he enters yours, he eats you." << endl;
	cout << "- You can hear bats and smell the wumpus. If you feel a breeze, that means there is a pit nearby." << endl;

	cout << "\n---CONTROLS--\n";
	cout << "- To move type 'm' followed by the room number. Example: m13" << endl;
	cout << "- To shoot type 's' followed by the room number. Example: s13" << endl;

	cout << "\nMaybe other things will happen in the cave...who knows? All those who have ventured in, have not returned..." << endl;
	cout << "It's time to go and Hunt the Wumpus. ";
	cout << "\nPress continue...";
}

// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------