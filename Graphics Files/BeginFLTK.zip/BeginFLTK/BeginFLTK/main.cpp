// -----------------------------------------------------------------------------
// https://lptcp.blogspot.com
// FLTK - Getting started
/*
   Simple project to get you started at the beginning of Chapter 12.
*/
//	https://github.com/l-paz91/principles-practice
// -----------------------------------------------------------------------------

//--INCLUDES--//
#include <FL/Fl.H>
#include <FL/Fl_Box.h>
#include <FL/FL_Window.h>

// -----------------------------------------------------------------------------

int main()
{
	Fl_Window window(200, 200, "Window Title");
	Fl_Box box(0, 0, 200, 200, "Hello, window!");
	window.show();

	return Fl::run();
}

// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------
// -----------------------------------------------------------------------------